# Networking Portfolio — Flask + Render

A personal portfolio website for network engineers, built with Python/Flask and deployable on Render.

## Project Structure

```
portfolio/
├── app.py               # Flask application
├── requirements.txt     # Python dependencies
├── Procfile             # Gunicorn start command
├── render.yaml          # Render deployment config
├── templates/
│   └── index.html       # Main HTML page
└── static/
    ├── css/style.css    # Stylesheet
    └── js/main.js       # Animations & interactions
```

## Run Locally

```bash
pip install -r requirements.txt
python app.py
```

Then open http://localhost:5000

## Deploy to Render

1. Push this folder to a GitHub repository
2. Go to https://render.com and sign in
3. Click **New → Web Service**
4. Connect your GitHub repo
5. Render auto-detects the config from `render.yaml`
6. Click **Deploy** — your site will be live in ~2 minutes

## Customizing Your Info

Edit `templates/index.html` and update:
- Your name, title, and contact details
- Skills, certifications, and project descriptions
- Social links (LinkedIn, GitHub, email)

No Python changes needed — all content is in the HTML template.
